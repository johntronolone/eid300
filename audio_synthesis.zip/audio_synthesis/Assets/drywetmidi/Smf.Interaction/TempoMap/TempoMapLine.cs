﻿namespace Melanchall.DryWetMidi.Smf.Interaction
{
    internal enum TempoMapLine
    {
        Tempo,
        TimeSignature
    }
}
