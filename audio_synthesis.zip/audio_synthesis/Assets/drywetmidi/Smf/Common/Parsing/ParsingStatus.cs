﻿namespace Melanchall.DryWetMidi.Common
{
    internal enum ParsingStatus
    {
        Parsed,
        EmptyInputString,
        NotMatched,
        FormatError
    }
}
