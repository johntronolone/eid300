﻿using Melanchall.DryWetMidi.Smf;

namespace Melanchall.DryWetMidi.Tools
{
    internal delegate string EventNameGetter(MidiEvent midiEvent);
}
