﻿namespace Melanchall.DryWetMidi.Tools
{
    /// <summary>
    /// Settings according to which objects should be randomized.
    /// </summary>
    public abstract class RandomizingSettings
    {
    }
}
