﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Node_Osc : MonoBehaviour
{
    private Vector3 spherePosition;
    private float xzPosition, yPosition;
    private float increaseXZPosition, increaseYPosition;

    // Start is called before the first frame update
    void Start()
    {
        // Three seconds per circular rotation.
        increaseXZPosition = (2.0f * Mathf.PI) / 3.0f;

        // Random speed up/down.
        increaseYPosition = (2.0f * Mathf.PI) / 1.3f;

    }

    // Update is called once per frame
    void Update()
    {
        spherePosition = new Vector3(2.0f * Mathf.Sin(xzPosition), 4.0f * Mathf.Sin(yPosition), 2.0f * Mathf.Cos(xzPosition));
        transform.position = spherePosition;

        // Update the rotating position.
        xzPosition += increaseXZPosition * Time.deltaTime;
        if (xzPosition > 2.0f * Mathf.PI)
        {
            xzPosition = xzPosition - 2.0f * Mathf.PI;
        }

        // Update the up/down position.
        yPosition += increaseYPosition * Time.deltaTime;
        if (yPosition > Mathf.PI)
        {
            yPosition = yPosition - Mathf.PI;
        }
    }
}