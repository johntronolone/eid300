﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class nodeOscillation : MonoBehaviour
{
    private Vector3 spherePosition;
    private float xzPosition, yPosition;
    private float increaseXZPosition, increaseYPosition;

    // Get velocity of striking object
    // Use velocity to adjust amplitude

    // Determine amplitude of oscilattion using distance from origin

    // Start is called before the first frame update
    void Start()
    {
        // Three seconds is period.
        increaseXZPosition = (2.0f * Mathf.PI) / 3.0f;
    }

    // Update is called once per frame
    void Update()
    {
        spherePosition = new Vector3(2.0f * Mathf.Sin(xzPosition), 0, 0);
        transform.position = spherePosition;

        // Update the rotating position.
        xzPosition += increaseXZPosition * Time.deltaTime;
        if (xzPosition > 2.0f * Mathf.PI)
        {
            xzPosition = xzPosition - 2.0f * Mathf.PI;
        }
    }
}